# Sistema de Controle de Estoque - Documentação da API

## Visão Geral

Sistema web para controle de estoque de produtos de limpeza com autenticação simulada, cadastro de produtos, registro de movimentações e alertas automáticos.

## Arquitetura

- **Backend**: Node.js + Express (porta 3001)
- **Frontend**: HTML + CSS + JavaScript puro
- **Armazenamento**: Dados em memória (arrays JavaScript)
- **Comunicação**: REST API com fetch()

---

## Endpoints da API

### 1. Autenticação

#### POST /login

Autenticação simulada do usuário.

**Request Body:**
\`\`\`json
{
  "identificador": "joao.silva"
}
\`\`\`

**Response (200 OK):**
\`\`\`json
{
  "sucesso": true,
  "nome": "João Silva",
  "identificador": "joao.silva"
}
\`\`\`

**Response (400 Bad Request):**
\`\`\`json
{
  "erro": "Identificador é obrigatório"
}
\`\`\`

---

### 2. Produtos

#### POST /produtos

Cadastrar novo produto.

**Request Body:**
\`\`\`json
{
  "nome": "Detergente Líquido",
  "marca": "Limpol",
  "composicaoQuimica": "Tensoativos aniônicos, coadjuvantes, conservantes",
  "fragrancia": "Limão",
  "volume": "500ml",
  "tipoEmbalagem": "Plástico PET",
  "aplicacao": "Limpeza de louças e utensílios",
  "lote": "L20240115",
  "validade": "2026-01-15",
  "estoqueInicial": 100,
  "estoqueMinimo": 20
}
\`\`\`

**Response (201 Created):**
\`\`\`json
{
  "sucesso": true,
  "produto": {
    "id": 1,
    "nome": "Detergente Líquido",
    "marca": "Limpol",
    "composicaoQuimica": "Tensoativos aniônicos, coadjuvantes, conservantes",
    "fragrancia": "Limão",
    "volume": "500ml",
    "tipoEmbalagem": "Plástico PET",
    "aplicacao": "Limpeza de louças e utensílios",
    "lote": "L20240115",
    "validade": "2026-01-15",
    "estoqueAtual": 100,
    "estoqueMinimo": 20,
    "dataCadastro": "2024-01-15T10:30:00.000Z"
  }
}
\`\`\`

**Response (400 Bad Request):**
\`\`\`json
{
  "erro": "Todos os campos são obrigatórios"
}
\`\`\`

#### GET /produtos

Listar produtos com filtros opcionais.

**Query Parameters:**
- `nome` (opcional): Filtro por nome (busca parcial, case-insensitive)
- `marca` (opcional): Filtro por marca (busca parcial, case-insensitive)
- `apenasAbaixoMinimo` (opcional): "true" para filtrar apenas produtos abaixo do estoque mínimo

**Exemplos:**
- `GET /produtos` - Todos os produtos
- `GET /produtos?nome=detergente` - Produtos com "detergente" no nome
- `GET /produtos?marca=limpol` - Produtos da marca "Limpol"
- `GET /produtos?apenasAbaixoMinimo=true` - Apenas produtos abaixo do mínimo

**Response (200 OK):**
\`\`\`json
{
  "sucesso": true,
  "total": 5,
  "produtos": [
    {
      "id": 1,
      "nome": "Detergente Líquido",
      "marca": "Limpol",
      "estoqueAtual": 100,
      "estoqueMinimo": 20,
      "..."
    }
  ]
}
\`\`\`

#### GET /produtos/:id

Obter detalhes de um produto específico.

**Response (200 OK):**
\`\`\`json
{
  "sucesso": true,
  "produto": {
    "id": 1,
    "nome": "Detergente Líquido",
    "marca": "Limpol",
    "..."
  }
}
\`\`\`

**Response (404 Not Found):**
\`\`\`json
{
  "erro": "Produto não encontrado"
}
\`\`\`

---

### 3. Movimentações de Estoque

#### PUT /estoque/entrada

Registrar entrada de estoque.

**Request Body:**
\`\`\`json
{
  "produtoId": 1,
  "quantidade": 50,
  "responsavel": "João Silva",
  "observacao": "Compra mensal"
}
\`\`\`

**Response (200 OK):**
\`\`\`json
{
  "sucesso": true,
  "produto": {
    "id": 1,
    "nome": "Detergente Líquido",
    "estoqueAtual": 150,
    "..."
  },
  "movimentacao": {
    "id": 1,
    "tipo": "entrada",
    "produtoId": 1,
    "produtoNome": "Detergente Líquido",
    "quantidade": 50,
    "estoqueAnterior": 100,
    "estoqueNovo": 150,
    "responsavel": "João Silva",
    "observacao": "Compra mensal",
    "dataHora": "2024-01-15T14:30:00.000Z"
  }
}
\`\`\`

**Response (400 Bad Request):**
\`\`\`json
{
  "erro": "Produto ID, quantidade e responsável são obrigatórios"
}
\`\`\`

#### PUT /estoque/saida

Registrar saída de estoque.

**Request Body:**
\`\`\`json
{
  "produtoId": 1,
  "quantidade": 30,
  "responsavel": "João Silva",
  "observacao": "Distribuição para setor de limpeza"
}
\`\`\`

**Response (200 OK):**
\`\`\`json
{
  "sucesso": true,
  "produto": {
    "id": 1,
    "nome": "Detergente Líquido",
    "estoqueAtual": 120,
    "..."
  },
  "movimentacao": {
    "id": 2,
    "tipo": "saida",
    "produtoId": 1,
    "produtoNome": "Detergente Líquido",
    "quantidade": 30,
    "estoqueAnterior": 150,
    "estoqueNovo": 120,
    "responsavel": "João Silva",
    "observacao": "Distribuição para setor de limpeza",
    "dataHora": "2024-01-15T15:00:00.000Z"
  },
  "alerta": null
}
\`\`\`

**Response com Alerta (200 OK):**
\`\`\`json
{
  "sucesso": true,
  "produto": { "..." },
  "movimentacao": { "..." },
  "alerta": "Estoque abaixo do mínimo!"
}
\`\`\`

**Response (400 Bad Request - Estoque Insuficiente):**
\`\`\`json
{
  "erro": "Estoque insuficiente",
  "estoqueDisponivel": 15
}
\`\`\`

---

### 4. Alertas

#### GET /alertas

Listar produtos com estoque abaixo do mínimo.

**Response (200 OK):**
\`\`\`json
{
  "sucesso": true,
  "total": 2,
  "produtos": [
    {
      "id": 1,
      "nome": "Detergente Líquido",
      "marca": "Limpol",
      "estoqueAtual": 15,
      "estoqueMinimo": 20,
      "diferenca": 5,
      "..."
    }
  ]
}
\`\`\`

---

### 5. Histórico

#### GET /movimentacoes

Listar movimentações com filtros opcionais.

**Query Parameters:**
- `produtoId` (opcional): Filtrar por produto específico
- `tipo` (opcional): "entrada" ou "saida"
- `dataInicio` (opcional): Data inicial (formato: YYYY-MM-DD)
- `dataFim` (opcional): Data final (formato: YYYY-MM-DD)

**Exemplos:**
- `GET /movimentacoes` - Todas as movimentações
- `GET /movimentacoes?produtoId=1` - Movimentações do produto 1
- `GET /movimentacoes?tipo=entrada` - Apenas entradas
- `GET /movimentacoes?dataInicio=2024-01-01&dataFim=2024-01-31` - Movimentações de janeiro/2024

**Response (200 OK):**
\`\`\`json
{
  "sucesso": true,
  "total": 15,
  "movimentacoes": [
    {
      "id": 1,
      "tipo": "entrada",
      "produtoId": 1,
      "produtoNome": "Detergente Líquido",
      "quantidade": 50,
      "estoqueAnterior": 100,
      "estoqueNovo": 150,
      "responsavel": "João Silva",
      "observacao": "Compra mensal",
      "dataHora": "2024-01-15T14:30:00.000Z"
    }
  ]
}
\`\`\`

---

## Códigos de Status HTTP

- **200 OK**: Requisição bem-sucedida
- **201 Created**: Recurso criado com sucesso
- **400 Bad Request**: Dados inválidos ou campos obrigatórios ausentes
- **404 Not Found**: Recurso não encontrado

---

## Estrutura de Dados

### Produto
\`\`\`javascript
{
  id: Number,                    // Gerado automaticamente
  nome: String,                  // Nome do produto
  marca: String,                 // Marca do produto
  composicaoQuimica: String,     // Composição química
  fragrancia: String,            // Fragrância do produto
  volume: String,                // Volume (ex: "500ml")
  tipoEmbalagem: String,         // Tipo de embalagem
  aplicacao: String,             // Aplicação do produto
  lote: String,                  // Número do lote
  validade: String,              // Data de validade (ISO 8601)
  estoqueAtual: Number,          // Quantidade atual em estoque
  estoqueMinimo: Number,         // Estoque mínimo para alerta
  dataCadastro: String           // Data de cadastro (ISO 8601)
}
\`\`\`

### Movimentação
\`\`\`javascript
{
  id: Number,                    // Gerado automaticamente
  tipo: String,                  // "entrada" ou "saida"
  produtoId: Number,             // ID do produto
  produtoNome: String,           // Nome do produto
  quantidade: Number,            // Quantidade movimentada
  estoqueAnterior: Number,       // Estoque antes da movimentação
  estoqueNovo: Number,           // Estoque após a movimentação
  responsavel: String,           // Nome do responsável
  observacao: String,            // Observação opcional
  dataHora: String               // Data e hora (ISO 8601)
}
\`\`\`

---

## Como Executar

### 1. Instalar Dependências

\`\`\`bash
cd api
npm install
\`\`\`

### 2. Iniciar o Servidor

\`\`\`bash
npm start
\`\`\`

O servidor estará disponível em `http://localhost:3001`

### 3. Abrir o Frontend

Abra o arquivo `frontend/login.html` no navegador ou use um servidor local:

\`\`\`bash
cd frontend
npx serve
\`\`\`

---

## Fluxo de Uso

1. **Login**: Acesse `login.html` e faça login com um identificador (ex: joao.silva)
2. **Menu Principal**: Será redirecionado para `index.html` com opções do sistema
3. **Cadastrar Produto**: Acesse `cadastro.html` para adicionar produtos
4. **Gerenciar Estoque**: Use `estoque.html` para registrar entradas/saídas
5. **Ver Alertas**: Acesse `alertas.html` para produtos abaixo do mínimo
6. **Histórico**: Consulte `historico.html` para ver todas as movimentações

---

## Observações

- Os dados são armazenados em memória e serão perdidos ao reiniciar o servidor
- A autenticação é simulada (não há senha)
- O sistema valida campos obrigatórios e quantidades
- Alertas são gerados automaticamente quando estoque < mínimo
- Todas as datas usam formato ISO 8601 (UTC)
