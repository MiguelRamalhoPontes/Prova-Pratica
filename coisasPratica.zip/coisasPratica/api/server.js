// Sistema de Controle de Estoque - API Backend
// Servidor Node.js com Express e MySQL

const express = require("express")
const cors = require("cors")
const mysql = require("mysql2/promise")
const app = express()
const PORT = 3001

const pool = mysql.createPool({
  host: process.env.DB_HOST || "localhost",
  user: process.env.DB_USER || "root",
  password: process.env.DB_PASSWORD || "",
  database: process.env.DB_NAME || "estoque_limpeza",
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
})

// Middleware
app.use(cors())
app.use(express.json())

async function testarConexao() {
  try {
    const connection = await pool.getConnection()
    console.log("✅ Conectado ao MySQL com sucesso!")
    connection.release()
  } catch (erro) {
    console.error("❌ Erro ao conectar ao MySQL:", erro.message)
    console.log("⚠️  Verifique se o MySQL está rodando e as credenciais estão corretas")
  }
}

testarConexao()

// ============================================
// ENDPOINT: POST /login
// Autenticação simulada
// ============================================
app.post("/login", (req, res) => {
  const { identificador } = req.body

  if (!identificador || identificador.trim() === "") {
    return res.status(400).json({
      erro: "Identificador é obrigatório",
    })
  }

  // Formatar nome (exemplo: joao.silva -> João Silva)
  const nomeFormatado = identificador
    .split(".")
    .map((parte) => parte.charAt(0).toUpperCase() + parte.slice(1))
    .join(" ")

  res.json({
    sucesso: true,
    nome: nomeFormatado,
    identificador: identificador,
  })
})

// ============================================
// ENDPOINT: POST /usuarios/registrar
// Registro de novo usuário
// ============================================
app.post("/usuarios/registrar", async (req, res) => {
  const { nome, identificador } = req.body

  // Validação de campos obrigatórios
  if (!nome || !identificador) {
    return res.status(400).json({
      erro: "Nome e identificador são obrigatórios",
    })
  }

  try {
    // Verificar se o identificador já existe
    const [usuariosExistentes] = await pool.execute("SELECT * FROM usuarios WHERE usuario = ?", [identificador])

    if (usuariosExistentes.length > 0) {
      return res.status(400).json({
        erro: "Identificador já cadastrado",
      })
    }

    // Inserir novo usuário
    const [resultado] = await pool.execute(`INSERT INTO usuarios (usuario, nome_completo) VALUES (?, ?)`, [
      identificador,
      nome,
    ])

    // Buscar o usuário recém-criado
    const [usuarios] = await pool.execute("SELECT * FROM usuarios WHERE id = ?", [resultado.insertId])

    const novoUsuario = {
      id: usuarios[0].id,
      usuario: usuarios[0].usuario,
      nomeCompleto: usuarios[0].nome_completo,
      criadoEm: usuarios[0].criado_em,
    }

    res.status(201).json({
      sucesso: true,
      usuario: novoUsuario,
    })
  } catch (erro) {
    console.error("Erro ao registrar usuário:", erro)
    res.status(500).json({
      erro: "Erro ao registrar usuário",
      detalhes: erro.message,
    })
  }
})

// ============================================
// ENDPOINT: POST /produtos
// Cadastro de novo produto
// ============================================
app.post("/produtos", async (req, res) => {
  const { nome, marca, volume, categoria, estoqueInicial, estoqueMinimo } = req.body

  // Validação de campos obrigatórios
  if (!nome || !marca || !volume || !categoria || estoqueInicial === undefined || estoqueMinimo === undefined) {
    return res.status(400).json({
      erro: "Todos os campos são obrigatórios",
    })
  }

  // Validar valores numéricos
  if (estoqueInicial < 0 || estoqueMinimo < 0) {
    return res.status(400).json({
      erro: "Estoque inicial e mínimo devem ser valores positivos",
    })
  }

  try {
    const [resultado] = await pool.execute(
      `INSERT INTO produtos 
       (nome, marca, volume, categoria, estoque, estoque_minimo)
       VALUES (?, ?, ?, ?, ?, ?)`,
      [nome, marca, volume, categoria, Number.parseInt(estoqueInicial), Number.parseInt(estoqueMinimo)],
    )

    // Buscar o produto recém-criado
    const [produtos] = await pool.execute("SELECT * FROM produtos WHERE id = ?", [resultado.insertId])

    const novoProduto = {
      id: produtos[0].id,
      nome: produtos[0].nome,
      marca: produtos[0].marca,
      volume: produtos[0].volume,
      categoria: produtos[0].categoria,
      estoqueAtual: produtos[0].estoque,
      estoqueMinimo: produtos[0].estoque_minimo,
    }

    res.status(201).json({
      sucesso: true,
      produto: novoProduto,
    })
  } catch (erro) {
    console.error("Erro ao cadastrar produto:", erro)
    res.status(500).json({
      erro: "Erro ao cadastrar produto",
      detalhes: erro.message,
    })
  }
})

// ============================================
// ENDPOINT: GET /produtos
// Listagem de produtos com filtros
// ============================================
app.get("/produtos", async (req, res) => {
  const { nome, marca, apenasAbaixoMinimo } = req.query

  try {
    let query = "SELECT * FROM produtos WHERE 1=1"
    const params = []

    // Filtro por nome (busca parcial, case-insensitive)
    if (nome) {
      query += " AND nome LIKE ?"
      params.push(`%${nome}%`)
    }

    // Filtro por marca (busca parcial, case-insensitive)
    if (marca) {
      query += " AND marca LIKE ?"
      params.push(`%${marca}%`)
    }

    // Filtro para produtos abaixo do mínimo
    if (apenasAbaixoMinimo === "true") {
      query += " AND estoque < estoque_minimo"
    }

    query += " ORDER BY nome"

    const [produtos] = await pool.execute(query, params)

    const produtosFormatados = produtos.map((p) => ({
      id: p.id,
      nome: p.nome,
      marca: p.marca,
      volume: p.volume,
      categoria: p.categoria,
      estoqueAtual: p.estoque,
      estoqueMinimo: p.estoque_minimo,
    }))

    res.json({
      sucesso: true,
      total: produtosFormatados.length,
      produtos: produtosFormatados,
    })
  } catch (erro) {
    console.error("Erro ao listar produtos:", erro)
    res.status(500).json({
      erro: "Erro ao listar produtos",
      detalhes: erro.message,
    })
  }
})

// ============================================
// ENDPOINT: GET /produtos/:id
// Detalhes de um produto específico
// ============================================
app.get("/produtos/:id", async (req, res) => {
  const id = Number.parseInt(req.params.id)

  try {
    const [produtos] = await pool.execute("SELECT * FROM produtos WHERE id = ?", [id])

    if (produtos.length === 0) {
      return res.status(404).json({
        erro: "Produto não encontrado",
      })
    }

    const p = produtos[0]
    const produto = {
      id: p.id,
      nome: p.nome,
      marca: p.marca,
      volume: p.volume,
      categoria: p.categoria,
      estoqueAtual: p.estoque,
      estoqueMinimo: p.estoque_minimo,
    }

    res.json({
      sucesso: true,
      produto,
    })
  } catch (erro) {
    console.error("Erro ao buscar produto:", erro)
    res.status(500).json({
      erro: "Erro ao buscar produto",
      detalhes: erro.message,
    })
  }
})

// ============================================
// ENDPOINT: PUT /estoque/entrada
// Registrar entrada de estoque
// ============================================
app.put("/estoque/entrada", async (req, res) => {
  const { produtoId, quantidade, usuarioId, observacao } = req.body

  // Validações
  if (!produtoId || !quantidade || !usuarioId) {
    return res.status(400).json({
      erro: "Produto ID, quantidade e usuário ID são obrigatórios",
    })
  }

  if (quantidade <= 0) {
    return res.status(400).json({
      erro: "Quantidade deve ser maior que zero",
    })
  }

  const connection = await pool.getConnection()
  try {
    await connection.beginTransaction()

    // Verificar se o usuário existe
    const [usuarios] = await connection.execute("SELECT * FROM usuarios WHERE id = ?", [Number.parseInt(usuarioId)])

    if (usuarios.length === 0) {
      await connection.rollback()
      return res.status(404).json({
        erro: "Usuário não encontrado",
      })
    }

    // Buscar produto
    const [produtos] = await connection.execute("SELECT * FROM produtos WHERE id = ?", [Number.parseInt(produtoId)])

    if (produtos.length === 0) {
      await connection.rollback()
      return res.status(404).json({
        erro: "Produto não encontrado",
      })
    }

    const produto = produtos[0]
    const estoqueAnterior = produto.estoque
    const estoqueNovo = estoqueAnterior + Number.parseInt(quantidade)

    // Atualizar estoque
    await connection.execute("UPDATE produtos SET estoque = ? WHERE id = ?", [estoqueNovo, produto.id])

    // Registrar movimentação com os campos do schema
    const [movimentacao] = await connection.execute(
      `INSERT INTO movimentacoes 
       (produto_id, usuario_id, tipo, quantidade, observacao)
       VALUES (?, ?, ?, ?, ?)`,
      [produto.id, Number.parseInt(usuarioId), "entrada", Number.parseInt(quantidade), observacao || null],
    )

    await connection.commit()

    res.json({
      sucesso: true,
      produto: {
        id: produto.id,
        nome: produto.nome,
        estoqueAtual: estoqueNovo,
        estoqueMinimo: produto.estoque_minimo,
      },
      movimentacao: {
        id: movimentacao.insertId,
        tipo: "entrada",
        quantidade: Number.parseInt(quantidade),
        usuarioId: Number.parseInt(usuarioId),
        observacao: observacao || null,
      },
    })
  } catch (erro) {
    await connection.rollback()
    console.error("Erro ao registrar entrada:", erro)
    res.status(500).json({
      erro: "Erro ao registrar entrada",
      detalhes: erro.message,
    })
  } finally {
    connection.release()
  }
})

// ============================================
// ENDPOINT: PUT /estoque/saida
// Registrar saída de estoque
// ============================================
app.put("/estoque/saida", async (req, res) => {
  const { produtoId, quantidade, usuarioId, observacao } = req.body

  // Validações
  if (!produtoId || !quantidade || !usuarioId) {
    return res.status(400).json({
      erro: "Produto ID, quantidade e usuário ID são obrigatórios",
    })
  }

  if (quantidade <= 0) {
    return res.status(400).json({
      erro: "Quantidade deve ser maior que zero",
    })
  }

  const connection = await pool.getConnection()
  try {
    await connection.beginTransaction()

    // Verificar se o usuário existe
    const [usuarios] = await connection.execute("SELECT * FROM usuarios WHERE id = ?", [Number.parseInt(usuarioId)])

    if (usuarios.length === 0) {
      await connection.rollback()
      return res.status(404).json({
        erro: "Usuário não encontrado",
      })
    }

    // Buscar produto
    const [produtos] = await connection.execute("SELECT * FROM produtos WHERE id = ?", [Number.parseInt(produtoId)])

    if (produtos.length === 0) {
      await connection.rollback()
      return res.status(404).json({
        erro: "Produto não encontrado",
      })
    }

    const produto = produtos[0]

    if (produto.estoque < Number.parseInt(quantidade)) {
      await connection.rollback()
      return res.status(400).json({
        erro: "Estoque insuficiente",
        estoqueDisponivel: produto.estoque,
      })
    }

    const estoqueAnterior = produto.estoque
    const estoqueNovo = estoqueAnterior - Number.parseInt(quantidade)

    // Atualizar estoque
    await connection.execute("UPDATE produtos SET estoque = ? WHERE id = ?", [estoqueNovo, produto.id])

    // Registrar movimentação com os campos do schema
    const [movimentacao] = await connection.execute(
      `INSERT INTO movimentacoes 
       (produto_id, usuario_id, tipo, quantidade, observacao)
       VALUES (?, ?, ?, ?, ?)`,
      [produto.id, Number.parseInt(usuarioId), "saida", Number.parseInt(quantidade), observacao || null],
    )

    await connection.commit()

    res.json({
      sucesso: true,
      produto: {
        id: produto.id,
        nome: produto.nome,
        estoqueAtual: estoqueNovo,
        estoqueMinimo: produto.estoque_minimo,
      },
      movimentacao: {
        id: movimentacao.insertId,
        tipo: "saida",
        quantidade: Number.parseInt(quantidade),
        usuarioId: Number.parseInt(usuarioId),
        observacao: observacao || null,
      },
      alerta: estoqueNovo < produto.estoque_minimo ? "Estoque abaixo do mínimo!" : null,
    })
  } catch (erro) {
    await connection.rollback()
    console.error("Erro ao registrar saída:", erro)
    res.status(500).json({
      erro: "Erro ao registrar saída",
      detalhes: erro.message,
    })
  } finally {
    connection.release()
  }
})

// ============================================
// ENDPOINT: GET /alertas
// Produtos com estoque abaixo do mínimo
// ============================================
app.get("/alertas", async (req, res) => {
  try {
    const [produtos] = await pool.execute(
      "SELECT * FROM produtos WHERE estoque < estoque_minimo ORDER BY (estoque_minimo - estoque) DESC",
    )

    const produtosFormatados = produtos.map((p) => ({
      id: p.id,
      nome: p.nome,
      marca: p.marca,
      volume: p.volume,
      categoria: p.categoria,
      estoqueAtual: p.estoque,
      estoqueMinimo: p.estoque_minimo,
      diferenca: p.estoque_minimo - p.estoque,
    }))

    res.json({
      sucesso: true,
      total: produtosFormatados.length,
      produtos: produtosFormatados,
    })
  } catch (erro) {
    console.error("Erro ao buscar alertas:", erro)
    res.status(500).json({
      erro: "Erro ao buscar alertas",
      detalhes: erro.message,
    })
  }
})

// ============================================
// ENDPOINT: GET /movimentacoes
// Histórico de movimentações com filtros
// ============================================
app.get("/movimentacoes", async (req, res) => {
  const { produtoId, dataInicio, dataFim, tipo } = req.query

  try {
    let query = `
      SELECT m.*, p.nome as produto_nome, u.nome_completo as usuario_nome
      FROM movimentacoes m
      INNER JOIN produtos p ON m.produto_id = p.id
      INNER JOIN usuarios u ON m.usuario_id = u.id
      WHERE 1=1
    `
    const params = []

    // Filtro por produto
    if (produtoId) {
      query += " AND m.produto_id = ?"
      params.push(Number.parseInt(produtoId))
    }

    // Filtro por tipo (entrada/saida)
    if (tipo) {
      query += " AND m.tipo = ?"
      params.push(tipo)
    }

    // Filtro por período
    if (dataInicio) {
      query += " AND m.data_hora >= ?"
      params.push(dataInicio)
    }

    if (dataFim) {
      query += " AND m.data_hora <= ?"
      params.push(dataFim)
    }

    // Ordenar por data (mais recentes primeiro)
    query += " ORDER BY m.data_hora DESC"

    const [movimentacoes] = await pool.execute(query, params)

    const movimentacoesFormatadas = movimentacoes.map((m) => ({
      id: m.id,
      tipo: m.tipo,
      produtoId: m.produto_id,
      produtoNome: m.produto_nome,
      usuarioId: m.usuario_id,
      usuarioNome: m.usuario_nome,
      quantidade: m.quantidade,
      observacao: m.observacao,
      dataHora: m.data_hora,
    }))

    res.json({
      sucesso: true,
      total: movimentacoesFormatadas.length,
      movimentacoes: movimentacoesFormatadas,
    })
  } catch (erro) {
    console.error("Erro ao buscar movimentações:", erro)
    res.status(500).json({
      erro: "Erro ao buscar movimentações",
      detalhes: erro.message,
    })
  }
})

// Iniciar servidor
app.listen(PORT, () => {
  console.log(`🚀 Servidor rodando em http://localhost:${PORT}`)
  console.log(`📦 Sistema de Controle de Estoque - API pronta com MySQL!`)
})
